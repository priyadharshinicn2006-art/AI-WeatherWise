// routes/authRoutes.js
// Defines endpoints for registration and login.

const express = require("express");
const router = express.Router();
const {
  registerUser,
  loginUser,
  getAllUsers,
} = require("../controllers/authController");
const { protect } = require("../middleware/authMiddleware");
const { authorizeRoles } = require("../middleware/roleMiddleware");

router.post("/register", registerUser);
router.post("/login", loginUser);

// Admin-only demo route: lists all registered users.
// Requires a valid JWT AND the "admin" role.
router.get("/admin/users", protect, authorizeRoles("admin"), getAllUsers);

module.exports = router;
