// routes/locationRoutes.js
// All routes here require a valid JWT (protect middleware).

const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/authMiddleware");
const {
  createLocation,
  getLocations,
  getLocationById,
  updateLocation,
  deleteLocation,
} = require("../controllers/locationController");

router.use(protect);

router.route("/").post(createLocation).get(getLocations);

router
  .route("/:id")
  .get(getLocationById)
  .put(updateLocation)
  .delete(deleteLocation);

module.exports = router;
