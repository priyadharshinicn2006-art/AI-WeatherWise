// routes/aiRoutes.js
// Requires JWT authentication - only logged-in users can request AI insights.

const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/authMiddleware");
const { getAiRecommendation } = require("../controllers/aiController");

router.post("/recommendation", protect, getAiRecommendation);

module.exports = router;
