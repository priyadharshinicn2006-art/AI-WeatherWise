// routes/weatherRoutes.js
// Public route - no authentication required (see weatherController.js
// for the reasoning behind this decision).

const express = require("express");
const router = express.Router();
const { getWeather } = require("../controllers/weatherController");

router.get("/", getWeather);

module.exports = router;
