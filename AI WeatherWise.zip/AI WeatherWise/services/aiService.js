// services/aiService.js
// This service sends real weather data to Google Gemini and asks it to
// generate a human-friendly summary, activity tips, clothing advice, and
// general guidance. The AI is instructed to only use the numbers we give
// it, never invent its own weather data.

const { GoogleGenAI } = require("@google/genai");

   const MODEL_NAME = "gemini-3.6-flash";

/**
 * Generates AI-powered weather insights based on real weather data.
 * @param {object} weatherData - output of weatherService.getCurrentWeather
 * @returns {Promise<{summary: string, activity: string, clothing: string, advice: string}>}
 */
const generateWeatherInsight = async (weatherData) => {
  const apiKey = process.env.GEMINI_API_KEY;

  if (!apiKey) {
    const error = new Error(
      "AI service is not configured (missing GEMINI_API_KEY)"
    );
    error.statusCode = 500;
    throw error;
  }

  const ai = new GoogleGenAI({ apiKey });

  const prompt = `
You are a weather assistant. Use ONLY the exact weather data given below.
Do NOT invent or change any numbers. Base every sentence strictly on this data.

Weather data:
- City: ${weatherData.city}, ${weatherData.country}
- Temperature: ${weatherData.temperature}°C
- Feels like: ${weatherData.feelsLike}°C
- Humidity: ${weatherData.humidity}%
- Wind speed: ${weatherData.windSpeed} m/s
- Condition: ${weatherData.condition}
- Description: ${weatherData.description}

Respond ONLY with a valid JSON object (no markdown, no code fences, no extra text)
in exactly this shape:
{
  "summary": "a short natural-language summary of the current weather",
  "activity": "a suggested outdoor/indoor activity suitable for this weather",
  "clothing": "clothing recommendation suitable for this weather",
  "advice": "one short piece of general practical advice for this weather"
}
`;

  let response;
  try {
    response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: prompt,
    });
       } catch (apiError) {
       console.error("GEMINI ERROR DETAILS:", apiError);
       const error = new Error("Failed to generate AI insight from Gemini");
       error.statusCode = 502;
       throw error;
   }

  const rawText = response.text || "";

  // Gemini sometimes wraps JSON in markdown code fences - strip them out
  const cleanText = rawText.replace(/```json|```/g, "").trim();

  try {
    const parsed = JSON.parse(cleanText);
    return {
      summary: parsed.summary || "Weather summary unavailable",
      activity: parsed.activity || "Activity suggestion unavailable",
      clothing: parsed.clothing || "Clothing suggestion unavailable",
      advice: parsed.advice || "No additional advice available",
    };
  } catch (parseError) {
    // Fallback: if Gemini did not return valid JSON, still return something useful
    return {
      summary: cleanText || "Weather summary unavailable",
      activity: "Activity suggestion unavailable",
      clothing: "Clothing suggestion unavailable",
      advice: "No additional advice available",
    };
  }
};

module.exports = { generateWeatherInsight };
