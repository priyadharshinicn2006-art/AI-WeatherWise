// services/weatherService.js
// This service is responsible for talking to the OpenWeatherMap API
// and returning clean, simplified weather data to the rest of the app.

const OPENWEATHER_BASE_URL = "https://api.openweathermap.org/data/2.5/weather";

/**
 * Fetches current weather data for a given city from OpenWeatherMap.
 * @param {string} city - Name of the city, e.g. "Chennai"
 * @returns {Promise<object>} simplified weather data
 */
const getCurrentWeather = async (city) => {
  const apiKey = process.env.OPENWEATHER_API_KEY;

  if (!apiKey) {
    const error = new Error(
      "Weather service is not configured (missing OPENWEATHER_API_KEY)"
    );
    error.statusCode = 500;
    throw error;
  }

  if (!city || typeof city !== "string" || city.trim() === "") {
    const error = new Error("City is required to fetch weather");
    error.statusCode = 400;
    throw error;
  }

  const url = `${OPENWEATHER_BASE_URL}?q=${encodeURIComponent(
    city
  )}&appid=${apiKey}&units=metric`;

  let response;
  try {
    response = await fetch(url);
  } catch (networkError) {
    const error = new Error(
      "Unable to reach the weather service. Please check your network connection"
    );
    error.statusCode = 500;
    throw error;
  }

  if (response.status === 404) {
    const error = new Error(`City "${city}" not found`);
    error.statusCode = 404;
    throw error;
  }

  if (response.status === 401) {
    const error = new Error(
      "Invalid OpenWeather API key. Please check OPENWEATHER_API_KEY in .env"
    );
    error.statusCode = 500;
    throw error;
  }

  if (!response.ok) {
    const error = new Error("Failed to fetch weather data");
    error.statusCode = response.status;
    throw error;
  }

  const data = await response.json();

  // Return only the fields the rest of the app actually needs
  return {
    city: data.name,
    country: data.sys?.country || "N/A",
    temperature: Math.round(data.main.temp),
    feelsLike: Math.round(data.main.feels_like),
    humidity: data.main.humidity,
    pressure: data.main.pressure,
    windSpeed: data.wind?.speed ?? null,
    condition: data.weather?.[0]?.main || "Unknown",
    description: data.weather?.[0]?.description || "No description",
    icon: data.weather?.[0]?.icon || null,
  };
};

module.exports = { getCurrentWeather };
