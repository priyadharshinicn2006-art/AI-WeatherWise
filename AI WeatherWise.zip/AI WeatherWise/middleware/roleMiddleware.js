// middleware/roleMiddleware.js
// This middleware restricts access to certain routes based on user role.
// It must be used AFTER authMiddleware's "protect", because it relies on
// req.user being already set.

const authorizeRoles = (...allowedRoles) => {
  return (req, res, next) => {
    if (!req.user || !req.user.role) {
      return res.status(401).json({
        success: false,
        message: "Not authorized, no user information found",
      });
    }

    if (!allowedRoles.includes(req.user.role)) {
      return res.status(403).json({
        success: false,
        message: `Access denied. Role '${req.user.role}' is not permitted to perform this action`,
      });
    }

    next();
  };
};

module.exports = { authorizeRoles };
