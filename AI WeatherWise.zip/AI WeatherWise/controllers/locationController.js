// controllers/locationController.js
// Handles CRUD operations for a logged-in user's favorite locations.
// Every function here assumes authMiddleware has already run and
// req.user.id is available.

const Location = require("../models/Location");

// @route   POST /api/locations
// @access  Private
const createLocation = async (req, res, next) => {
  try {
    const { city, country } = req.body;

    if (!city || typeof city !== "string" || city.trim() === "") {
      return res.status(400).json({
        success: false,
        message: "City is required",
      });
    }

    if (!country || typeof country !== "string" || country.trim() === "") {
      return res.status(400).json({
        success: false,
        message: "Country is required",
      });
    }

    const location = await Location.create({
      user: req.user.id,
      city: city.trim(),
      country: country.trim(),
    });

    return res.status(201).json({
      success: true,
      message: "Location saved successfully",
      data: location,
    });
  } catch (error) {
    next(error);
  }
};

// @route   GET /api/locations
// @access  Private
const getLocations = async (req, res, next) => {
  try {
    const locations = await Location.find({ user: req.user.id }).sort({
      createdAt: -1,
    });

    return res.status(200).json({
      success: true,
      count: locations.length,
      data: locations,
    });
  } catch (error) {
    next(error);
  }
};

// @route   GET /api/locations/:id
// @access  Private
const getLocationById = async (req, res, next) => {
  try {
    const location = await Location.findById(req.params.id);

    if (!location) {
      return res.status(404).json({
        success: false,
        message: "Location not found",
      });
    }

    // Ensure the location belongs to the logged-in user
    if (location.user.toString() !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: "You are not authorized to access this location",
      });
    }

    return res.status(200).json({
      success: true,
      data: location,
    });
  } catch (error) {
    next(error);
  }
};

// @route   PUT /api/locations/:id
// @access  Private
const updateLocation = async (req, res, next) => {
  try {
    const { city, country } = req.body;

    const location = await Location.findById(req.params.id);

    if (!location) {
      return res.status(404).json({
        success: false,
        message: "Location not found",
      });
    }

    if (location.user.toString() !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: "You are not authorized to update this location",
      });
    }

    if (city && typeof city === "string" && city.trim() !== "") {
      location.city = city.trim();
    }

    if (country && typeof country === "string" && country.trim() !== "") {
      location.country = country.trim();
    }

    await location.save();

    return res.status(200).json({
      success: true,
      message: "Location updated successfully",
      data: location,
    });
  } catch (error) {
    next(error);
  }
};

// @route   DELETE /api/locations/:id
// @access  Private
const deleteLocation = async (req, res, next) => {
  try {
    const location = await Location.findById(req.params.id);

    if (!location) {
      return res.status(404).json({
        success: false,
        message: "Location not found",
      });
    }

    if (location.user.toString() !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: "You are not authorized to delete this location",
      });
    }

    await location.deleteOne();

    return res.status(200).json({
      success: true,
      message: "Location deleted successfully",
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  createLocation,
  getLocations,
  getLocationById,
  updateLocation,
  deleteLocation,
};
