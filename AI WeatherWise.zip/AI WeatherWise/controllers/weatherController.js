// controllers/weatherController.js
// Handles the current-weather lookup endpoint.
//
// DESIGN DECISION: GET /api/weather is PUBLIC (no JWT required).
// Reason: checking the weather for a city is a harmless, read-only action
// that doesn't touch any user-specific data, so there's no need to force
// a login just to look up the weather. Favorite locations and AI insights,
// which ARE tied to a specific user, remain protected by JWT.

const { getCurrentWeather } = require("../services/weatherService");

// @route   GET /api/weather?city=Chennai
// @access  Public
const getWeather = async (req, res, next) => {
  try {
    const { city } = req.query;

    if (!city || typeof city !== "string" || city.trim() === "") {
      return res.status(400).json({
        success: false,
        message: "City query parameter is required, e.g. /api/weather?city=Chennai",
      });
    }

    const weatherData = await getCurrentWeather(city.trim());

    return res.status(200).json({
      success: true,
      data: weatherData,
    });
  } catch (error) {
    next(error);
  }
};

module.exports = { getWeather };
