// controllers/aiController.js
// Combines real weather data with Google Gemini to produce AI-powered
// insights (summary, activity, clothing, advice) for a given city.

const { getCurrentWeather } = require("../services/weatherService");
const { generateWeatherInsight } = require("../services/aiService");

// @route   POST /api/ai/recommendation
// @access  Private
const getAiRecommendation = async (req, res, next) => {
  try {
    const { city } = req.body;

    if (!city || typeof city !== "string" || city.trim() === "") {
      return res.status(400).json({
        success: false,
        message: "City is required in the request body",
      });
    }

    // 1. Get real current weather data
    const weatherData = await getCurrentWeather(city.trim());

    // 2. Send that real data to Gemini to generate insights
    const aiInsight = await generateWeatherInsight(weatherData);

    // 3. Return combined response
    return res.status(200).json({
      success: true,
      city: weatherData.city,
      weather: {
        temperature: weatherData.temperature,
        feelsLike: weatherData.feelsLike,
        humidity: weatherData.humidity,
        windSpeed: weatherData.windSpeed,
        condition: weatherData.condition,
        description: weatherData.description,
      },
      aiInsight,
    });
  } catch (error) {
    next(error);
  }
};

module.exports = { getAiRecommendation };
